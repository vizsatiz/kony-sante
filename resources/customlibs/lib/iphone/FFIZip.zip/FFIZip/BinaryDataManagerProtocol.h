//
//  Callback.h
//  BinaryDataManager
//
//  Created by MBAAS on 20/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol BinaryDataManagerDelegate <NSObject>

@required
- (void)didCreateDownloadTaskForID:(NSString *)blobID;

- (void)errorInCreatingDownloadTaskForPKValues:(NSDictionary *)primaryKeyTable;



- (void)didCompleteDownloadProcessForID:(NSString *)blobID
                             withOutput:(NSDictionary *)response;

- (void)errorInCompletingDownloadProcessForID:(NSString *)taskID
                                       blobID:(NSString *)blobID
                                    withError:(NSDictionary *)error;



- (void)retrivedBinaryDataFilePath:(NSString *)filePath;

- (void)errorInRetrivingBinaryDataFilePath:(NSDictionary *)primaryKeys;
@end
