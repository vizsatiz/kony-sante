//
//  DownloadTask.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 08/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <Task/Task.h>
#import "BinaryDataManager.h"

@interface DownloadTask : KSTask <KSTaskListener>

@property (nonatomic, copy) startDownloadTaskCompletionBlock startDownloadTaskCompletionBlock;
@property (nonatomic, copy) pauseDownloadTaskCompletionBlock pauseDownloadTaskCompletionBlock;
@property (nonatomic, copy) resumeDownloadTaskCompletionBlock resumeDownloadTaskCompletionBlock;

-(void) pauseDownload;
-(void) resumeDownload;
-(void)updateInputContext:(NSDictionary *)newInputContext;
-(instancetype) initWithName:(NSString *)name;

@end
