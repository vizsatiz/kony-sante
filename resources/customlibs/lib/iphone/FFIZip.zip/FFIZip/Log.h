//
//  Log.h
//  BinaryDataManager
//
//  Created by Mukesh Sharma on 22/05/17.
//  Copyright © 2017 kony. All rights reserved.
//

#ifdef DEBUG
#define DLog( s, ... ) NSLog( @"<%p %@:(%d)> %@", self, [[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, [NSString stringWithFormat:(s), ##__VA_ARGS__] )
#else
#define DLog( s, ... )
#endif
