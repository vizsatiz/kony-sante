//
//  SQLiteUtil.h
//  FMDBTest
//
//  Created by Krishna Nikhil Vedurumudi on 16/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FMDatabase.h"

@interface SQLiteUtil : NSObject

/*
 in table name.
 config will contains key value pairs..
 */

+ (BOOL) insertStatementForDatabase:(FMDatabase *)db
                           ForTable:(NSString *)tableName
                         withValues:(NSDictionary *)config;


+ (FMResultSet *) queryDataForDatabase:(FMDatabase *)db
                              ForTable:(NSString *)tableName
                       withWhereClause:(NSDictionary *)whereClause;


+ (BOOL) updateStatementForDatabase:(FMDatabase *)db
                           forTable:(NSString *)tableName
             withColumnsToBeUpdated:(NSDictionary *)columnNames
                    withWhereClause:(NSDictionary *)whereClause;


+ (BOOL) deleteStatementForDatabase:(FMDatabase *)db
                           forTable:(NSString *)tableName
                    withWhereClause:(NSDictionary *)whereClause;

+ (long) getLastInsertID:(FMDatabase *)db;

+ (NSString *)buildWhereClauseForConditions:(NSDictionary *)whereClause;


@end
