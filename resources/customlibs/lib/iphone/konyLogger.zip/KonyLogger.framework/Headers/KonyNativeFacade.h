//
//  KonyNativeFacade.h
//  logger_abc
//
//  Created by MADP on 06/12/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IPersistor.h"
#import "LoggerError.h"
#import "LoggerConfig.h"
#import "BaseLogPersister.h"

@interface KonyNativeFacade : NSObject

/**-----------------------------------------------------------------------------
 * @name Setting the logger config through Native layer.
 
 Sets the loggerConfig to the loggerEngine.
 This is the first method that must be invoked to initialize the logger engine from the FFI layer.
 @param loggerConfig -The logger configuration for the loggerEngine, containing logFilterConfig and LogAccumulatorConfig.
 @param error -A nullable LoggerError instance passed as a parameter, assigned with an errorCode, errorDomain, errorDescription and errorCause(optional)  in case of error,can also be logged on the console.
 */
- (id)initWithLogger:(NSString *)loggerName
              config:(LoggerConfig*)loggerConfig
               error:(LoggerError **)error;

/**-----------------------------------------------------------------------------
 * @name Adding the persister through facade layer.
 * -----------------------------------------------------------------------------
 */

/**
 Adds persisterConfig to the the loggerEngine.
 This method can be invoked any number of times to add multiple persisters each time.
 @param persisterConfig -The persister configuration for the loggerEngine, containing persisterType,  and LogAccumulatorConfig.
 @param error -A nullable method passed as a parameter, invoked in case of containing persisterType, and its properties.
 */
+ (BaseLogPersister *)setPersisterConfig:(id<IPersistor>)persisterConfig
                                   error:(LoggerError **)error;

+(void)setConfig:(LoggerConfig *)config
           error:(LoggerError **)error;

+(void) activatePersistors: (NSNumber*) persistorType;
+(void) deactivatePersistors: (NSNumber*) persistorType;
/**-----------------------------------------------------------------------------
 * @name Main logging utilities through facade layer.
 * -----------------------------------------------------------------------------
 */

/**
 * SET LOG LEVEL
 * @param logLevel -logLevel to be set to logFilter
 */
+ (void)setLogLevel:(NSUInteger *)logLevel
              error:(LoggerError **)error;

/**
 * SET LOG LEVEL
 * @param logLevel -logLevel to be set and activate network persister
 */
+(void)setLogLevelAndActivateNetworkPersister:(NSString*)logLevel;

/**
 * GET LOG LEVEL
 * @return logLevel -logLevel set to logFilter
 */
+ (NSUInteger)getLogLevel;

/**
 * FLUSH the accumulated logs.
 */
+ (void)flushWithError:(LoggerError **)error;

/**
* setting indirection level.
* @param _indirectionLevel hop count to set indirection
*/
-(void)setIndirectionLevel:(int) _indirectionLevel;
/**
 * TRACE statement
 * @param statement -Statement to be logged
 */
- (void)logTrace:(NSString *)statement
           error:(LoggerError **)error;

/**
 * DEBUG statement
 * @param statement -Statement to be logged
 */
- (void)logDebug:(NSString *)statement
           error:(LoggerError **)error;

/**
 * WARNING statement
 * @param statement -Statement to be logged
 */
- (void)logWarning:(NSString *)statement
             error:(LoggerError **)error;

/**
 * INFO statement
 * @param statement -Statement to be logged
 */
- (void)logInfo:(NSString *)statement
          error:(LoggerError **)error;

/**
 * ERROR statement
 * @param statement -Statement to be logged
 */
- (void)logError:(NSString *)statement
           error:(LoggerError **)error;

/**
 * FATAL statement
 * @param statement -Statement to be logged
 */
- (void)logFatal:(NSString *)statement
           error:(LoggerError **)error;

@end
